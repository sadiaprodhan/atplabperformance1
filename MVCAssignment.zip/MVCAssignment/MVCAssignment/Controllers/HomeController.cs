﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCAssignment.Controllers
{
    public class Person
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string Gender { get; set; }
        public string Day { get; set; }
        public string Month { get; set; }
        public string Year { get; set; }


    }
    public class Login
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Person p)
        {
          
            if (p.Name == null || p.Email == null || p.Username == null || p.Password == null || p.ConfirmPassword == null || p.Gender == null || p.Day == null || p.Month == null || p.Year == null)
            { return Content(ViewBag.error = "Field cannot be empty" );}
            else
            {
                var a = p.Name.ToCharArray();
                for (int i = 0; i < a.Length; i++)
                {
                    if ((a[i] >= 'a' && a[i] <= 'z') || (a[i] >= 'A' && a[i]<= 'Z'))
                    {

                        continue;
                    }
                    else
                        ViewBag.error = "name should only contain alphabets";
                    break;

                }
                if(ViewBag.error!= null)
                { return Content(ViewBag.error); }
               
            }

                if (p.Password != p.ConfirmPassword)
                {

                   return Content( ViewBag.error = "Password does not match");


                }
                var day = p.Day.ToCharArray();
                var month= p.Month.ToCharArray();
                var year = p.Year.ToCharArray();
                for (int i = 0; i < day.Length; i++)
                {
                    if (day[i]>='0' && day[i]<='9')
                    {
                        continue;
                        
                    }
                    else
                        ViewBag.error = "day has to be neumeric";
                    break;

                }
                for (int i = 0; i < month.Length; i++)
                {
                    if (month[i] >= '0' && month[i] <= '9')
                    {

                        continue;
                    }
                    else
                        ViewBag.error = "month has to be neumeric";
                    break;

                }
                for (int i = 0; i < year.Length; i++)
                {
                    if (year[i] >= '0' && year[i] <= '9')
                    {

                        continue;
                    }
                    else
                        ViewBag.error = "year has to be neumeric";
                    break;
                }
                
                if (ViewBag.error != null)
                { return Content( ViewBag.error); }

                else
                {
                    Session["username"] = p.Username;
                    Session["password"] = p.Password;
                    return View("Login");
                }
                


        }
        [HttpPost]
        public ActionResult Login (Login p)
        {
            if (p.Username == null || p.Password == null)
            { return  Content(ViewBag.msg = "cannot be empty"); }
            else if (Session["username"] == p.Username && Session["password"] == p.Password)
             { return Content(ViewBag.msg = "Password and user name matched"); }
            else
            { return Content(ViewBag.msg = "Password and user name matched"); }
        
        }
      
       



                
            
            

        }
    }

